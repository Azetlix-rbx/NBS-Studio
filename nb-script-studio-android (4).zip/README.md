# NB Script Studio (Android, Java)

Редактор скриптов Null's Brawl с подсказками, подсветкой и поиском ошибок.

Сборка: залей проект в GitHub, вкладка **Actions → Build APK → Artifacts → NBScriptStudio-apk**.
