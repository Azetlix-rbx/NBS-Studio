-- Симуляция игры для «Виртуального запуска». Ничего не меняет в настоящей игре.
local log = __log
local function fmt(v)
  if type(v) == "number" then
    if v == math.floor(v) and math.abs(v) < 1e15 then return string.format("%.0f", v) end
    return tostring(v)
  end
  return tostring(v)
end
local function nm(x)
  if type(x) == "table" then
    local n = x.name
    if n == nil and type(x.data) == "table" then n = x.data.name end
    if n == nil and type(x.data) == "string" then n = x.data end
    return tostring(n or x)
  end
  return tostring(x)
end
print = function(...)
  local t = {}
  for i = 1, select("#", ...) do t[#t + 1] = tostring((select(i, ...))) end
  log(table.concat(t, "  "))
end

local function new(label, d, onset, build)
  local meths = {}
  local p
  p = setmetatable({}, {
    __index = function(_, k)
      local v = d[k]
      if v ~= nil then return v end
      return meths[k]
    end,
    __newindex = function(_, k, v)
      local o = d[k]
      d[k] = v
      onset(k, o, v)
    end,
    __tostring = function() return label end
  })
  local function def(name, f)
    meths[name] = function(a, ...)
      if a == p then return f(...) end
      return f(a, ...)
    end
  end
  build(p, def)
  return p
end

local function newSkill(owner, kind)
  return new(kind, {data = {name = kind}, charge = 0, activeTicksLeft = 0},
    function(k, o, v) log(owner .. ": " .. kind .. " " .. k .. " = " .. fmt(v)) end,
    function(p, def)
      def("setUpgradeLevel", function(l) log(owner .. ": " .. kind .. " получил уровень улучшения " .. fmt(l)) end)
    end)
end

local function newChar(i, name, team, x, y)
  local n = i + 1
  local P = "Игрок " .. n
  local d = {id = 100 + i, index = i, team = team, x = x, y = y, z = 0, dimension = 0,
    hitPoints = 4000, maxHitPoints = 4000, isBot = false, data = {name = name},
    persistentSpeedBuff = 0, persistentReloadBuff = 0, heroUpgradeLevel = 0,
    takingDamageListeners = {}, dealingDamageListeners = {}}
  return new(P, d, function(k, o, v)
    if k == "hitPoints" and type(v) == "number" and type(o) == "number" then
      if v >= o then
        log("Игроку " .. n .. " выдано " .. fmt(v) .. " ХП (было " .. fmt(o) .. ")")
      else
        log("У игрока " .. n .. " ХП снижено до " .. fmt(v) .. " (было " .. fmt(o) .. ")")
      end
    elseif k == "maxHitPoints" then
      log("Максимум ХП игрока " .. n .. " теперь " .. fmt(v))
    else
      log(P .. ": " .. k .. " = " .. fmt(v))
    end
  end, function(p, def)
    local sk = {}
    def("takeDamage", function(src, dmg)
      dmg = tonumber(dmg) or 0
      d.hitPoints = math.max(0, d.hitPoints - dmg)
      log(P .. " получил урон " .. fmt(dmg) .. " (осталось " .. fmt(d.hitPoints) .. " ХП)")
    end)
    def("takeHeal", function(src, hp)
      hp = tonumber(hp) or 0
      d.hitPoints = math.min(d.maxHitPoints, d.hitPoints + hp)
      log(P .. " вылечен на " .. fmt(hp) .. " ХП (стало " .. fmt(d.hitPoints) .. ")")
    end)
    def("stopMovement", function() log(P .. " остановлен") end)
    def("moveTo", function(x, y)
      d.x = x; d.y = y
      log(P .. " идёт к точке (" .. fmt(x) .. ", " .. fmt(y) .. ")")
    end)
    def("teleport", function(x, y)
      d.x = x; d.y = y
      log(P .. " телепортирован в (" .. fmt(x) .. ", " .. fmt(y) .. ")")
    end)
    def("setPosition", function(x, y, z)
      d.x = x; d.y = y; d.z = z or d.z
      log(P .. " перемещён в (" .. fmt(x) .. ", " .. fmt(y) .. ", " .. fmt(d.z) .. ")")
    end)
    def("isAlive", function() return d.hitPoints > 0 end)
    def("getWeaponSkill", function()
      sk.w = sk.w or newSkill(P, "WeaponSkill")
      return sk.w
    end)
    def("getUltiSkill", function()
      sk.u = sk.u or newSkill(P, "UltimateSkill")
      return sk.u
    end)
    def("getSkill", function(data) return newSkill(P, "Skill " .. nm(data)) end)
    def("increaseMaxHitPoints", function(v)
      v = tonumber(v) or 0
      d.maxHitPoints = d.maxHitPoints + v
      d.hitPoints = d.hitPoints + v
      log("Максимум ХП игрока " .. n .. " увеличен на " .. fmt(v) .. " (теперь " .. fmt(d.maxHitPoints) .. ")")
    end)
    def("spawnCirclingAreaEffect", function(bonus, data)
      log(P .. " создал вращающуюся зону \"" .. nm(data) .. "\"")
    end)
  end)
end

local players = {newChar(0, "ShotgunGirl", 0, 1200, 1500), newChar(1, "BullDude", 1, 2400, 1500)}
local clients = {}
for i, c in ipairs(players) do
  local P = "Игрок " .. i
  clients[i - 1] = new(P .. " (ClientInfo)", {index = i - 1, team = c.team, objectId = c.id, x = c.x, y = c.y,
    gamePoints = 0, ultiCharge = 0, maxUltiCharge = 1000, overchargeCharge = 0, maxOverchargeCharge = 1000,
    ultiUsesLeft = 1}, function(k, o, v) log(P .. ": " .. k .. " = " .. fmt(v)) end, function() end)
end

local function list(src)
  local items = {}
  for i, v in ipairs(src) do items[i] = v end
  local l = {}
  local M = {}
  local function def(name, f)
    M[name] = function(a, ...)
      if a == l then return f(...) end
      return f(a, ...)
    end
  end
  def("size", function() return #items end)
  def("get", function(i) return items[i + 1] end)
  def("add", function(o) items[#items + 1] = o; return true end)
  def("indexOf", function(o)
    for i, v in ipairs(items) do
      if v == o then return i - 1 end
    end
    return -1
  end)
  for i, v in ipairs(items) do l[i] = v end
  return setmetatable(l, {__index = M})
end

local TM = new("TileMap", {tileSizeX = 60, tileSizeY = 60, absSizeX = 3600, absSizeY = 3600},
  function(k, o, v) log("TileMap." .. k .. " = " .. fmt(v)) end,
  function(p, def)
    def("destructTile", function(x, y) log("Блок (" .. fmt(x) .. ", " .. fmt(y) .. ") разрушен") end)
    def("setDynamicTile", function(data, x, y)
      log("На (" .. fmt(x) .. ", " .. fmt(y) .. ") появился блок \"" .. nm(data) .. "\"")
    end)
    def("getTile", function(x, y)
      return new("Tile", {data = {name = "Tile"}, dataOriginal = {name = "Tile"}, x = x, y = y},
        function() end, function(q, d2) d2("isDynamic", function() return false end) end)
    end)
  end)

local OM = new("GameObjectManager", {}, function(k, o, v) log("objectManager." .. k .. " = " .. fmt(v)) end,
  function(p, def)
    def("getObject", function(id)
      for _, c in ipairs(players) do
        if c.id == id then return c end
      end
      return nil
    end)
    def("addObject", function(o)
      local x, y = 0, 0
      if type(o) == "table" then x = o.x or 0; y = o.y or 0 end
      log("Появился объект \"" .. nm(o) .. "\" на координатах (" .. fmt(x) .. ", " .. fmt(y) .. ")")
      return o
    end)
    def("getCharacters", function() return list(players) end)
    def("getAreaEffects", function() return list({}) end)
    def("getItems", function() return list({}) end)
    def("getProjectiles", function() return list({}) end)
  end)

Server = new("Server", {tick = 0, playersCount = #players, locationData = {name = "Тестовая локация"},
  gameMode = {name = "Тестовый режим"}, isBattleEnded = false, map = TM, objectManager = OM},
  function(k, o, v) log("Server." .. k .. " = " .. fmt(v)) end,
  function(p, def)
    def("getClientInfo", function(i) return clients[i] end)
    def("isIntroFinished", function() return true end)
    def("getRandomInt", function(a, b)
      a = a or 0; b = b or a
      if b < a then a, b = b, a end
      return math.random(a, b)
    end)
  end)
